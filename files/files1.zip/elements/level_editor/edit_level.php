<?php
    $level = null;
    $updated = null;

    // Get level details if not new
    if (is_numeric($_GET['edit'])) {
        $level = $app->levels->getLevelFromID($_GET['edit']);
        if (!$level) {
            $app->utils->message('Level not found');
            die();
        } else {
            if (isset($_POST['save'])) {
                $updated = $app->levels->editLevel($_GET['edit']);

                if ($updated) {
                   /* if (!isset($_GET['done']))
                        header('Location: '.$_SERVER[REQUEST_URI].'&done');
                    else
                        header('Location: '.$_SERVER[REQUEST_URI]); */

                    $app->utils->message('Level updated', 'good');
                    $level = $app->levels->getLevelFromID($_GET['edit']);
                }
            }
        }
    } else if ($_GET['edit'] === 'new') {
        if (isset($_POST['save'])) {
            $id = $app->levels->newLevel();

            if ($id !== false) {
                $app->utils->message('Level created', 'good');
                $level = $app->levels->getLevelFromID($id);
            } else {
                $app->utils->message('Error creating level');
            }
            die();
        }
    } else {
        $app->utils->message('Level not found');
        die();
    }
?>

<a class='button right' href='?edit=<?=$_GET['edit'];?>&form'>Edit form</a>
<h2><?=$level?$level->title:'New level';?></h2>

<?php if (isset($_GET['done'])) $app->utils->message('Level updated', 'good'); ?>

<form class='level-edit' method="POST">
    <div class='clr'>
<?php if (!$level): ?>
        <div class='col span_4'>
            <label for="name">Name:</label><br/>
            <input name="name" value="<?=isset($level->data['reward'])?$level->data['reward']:0;?>"/>
        </div>
<?php endif; ?>
        <div class='col span_6'>
            <label>Category:</label><br/>
            <div class='select-menu' data-id="category" data-value="">
                <label><?=isset($level->group)?htmlentities($level->group):'Category';?></label>
                <ul>
<?php
    $groups = $app->levels->getGroups();
    foreach($groups AS $group):
?>
                    <li><?=$group->title;?></li>
<?php
    endforeach;
?>
                </ul>
            </div>
        </div>
        <div class='col span_3'>
            <label for="reward">Reward:</label><br/>
            <input name="reward" value="<?=isset($level->data['reward'])?$level->data['reward']:0;?>"/>
        </div>
        <div class='col span_9'>
            <label for="uptime">Uptime:</label><br/>
            <input name="uptime" value="<?=isset($level->data['uptime'])?$level->data['uptime']:'';?>"/>
        </div>
    </div>

    <div class='clr'>
        <label>Description:</label><br/>
<?php
    $wysiwyg_enter = false;
    $wysiwyg_name = "description";
    $wysiwyg_text = isset($level->data['description'])?$level->data['description']:'';
    include('../../files/elements/wysiwyg.php');
?>
    </div>

    <div class='clr'>
        <div class='col span_12'>
            <label>Hint:</label>
<?php
//echo "edit_level.php realpath: ". realpath("./") ."<br/>";
    $wysiwyg_lite = true;
    $wysiwyg_name = "hint";
    $wysiwyg_text = isset($level->data['hint'])?$level->data['hint']:'';
    include('../../files/elements/wysiwyg.php');
?>
        </div>
        <div class='col span_12'>
            <label>Solution message:</label>
<?php
    $wysiwyg_name = "solution";
    $wysiwyg_text = isset($level->data['solution'])?$level->data['solution']:'';
    include('../../files/elements/wysiwyg.php');
?>
        </div>
    </div>
    <input type="hidden" name="save"/>
    <input type="hidden" value="<?=$app->generateCSRFKey("level-editor");?>" name="token">
    <input type="submit" class="button" value="Save"/>
</form>
