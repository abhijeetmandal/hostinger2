<form method="POST">
  <fieldset>
    <input type="hidden" name="category" value="plank">
    <input type="hidden" name="level" value="2">
    <input type="checkbox" id="confirm" name="confirm" value="checked"/>
     <label for="confirm">I confirm</label>
    <input type="submit" class="button" value="Submit">
  </fieldset>
</form>