<br/>
<a href=<?=$app->user->gdlink?>><image src="/files/images/google_drive_logo.png" alt="GOOGLE DRIVE" height="42" width="42"></a>
<br/>
<a href=<?=$app->user->gdlink?>>Upload link for you</a>
<br/><br/><br/>