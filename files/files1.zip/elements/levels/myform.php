<form method="POST">
  <fieldset>
    <input type="hidden" name="category" value="plank">
    <input type="hidden" name="level" value="1">
  </fieldset>
</form>