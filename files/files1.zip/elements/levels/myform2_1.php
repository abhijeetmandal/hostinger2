<form method="POST">
  <fieldset>
    <input type="hidden" name="category" value="main">
    <input type="hidden" name="level" value="1">
    <input type="checkbox" id="confirm" name="confirm" value="checked"/>
     <label for="confirm">I confirm</label>
    <input type="submit" class="button" value="Submit">
  </fieldset>
</form>