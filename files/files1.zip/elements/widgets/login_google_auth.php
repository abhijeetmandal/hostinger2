                    <article class="widget widget-login">
                        <form id="g_auth_form" action="?g_auth" method="POST">
                            <label for="password">Google Authenticator Code:</label>
                            <input type="number" name="g_code" id="password">
                            <input type="submit" value="Submit" class="button">
                        </form>
                    </article>
