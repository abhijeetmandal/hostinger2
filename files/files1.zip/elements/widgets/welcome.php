                   <article class="widget scoreboard">
                        <h1>Welcome</h1>
                        Welcome to CrushIt!! and online fitness and training community. Please register or login to access all the content on offer.
                    </article>