                   <article class="widget feed">
                        <h1>Feed</h1>
                        <div class="feed_loading center">
                            <img src='/files/images/icons/loading.gif' class='icon'/>
                        </div>
                    </article>