<form id="myChallenge" method="POST">
  <fieldset>
    <input id="category" type="hidden" name="category" value="">
    <input id="challenge" type="hidden" name="challenge" value="">
    <input id="token" type="hidden" name="token" value="0">
  </fieldset>
</form>