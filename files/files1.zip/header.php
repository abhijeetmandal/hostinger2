<?php
    require_once('init.php');

    require_once('page_header.php');
?>