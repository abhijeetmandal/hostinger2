<?php
/*
 * A small PHP class that minifies website resources and reduces requests
 * 
 *
 * -- MIT license -- 
 * Copyright (c) 2013 Luke Ward
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * The Software shall be used for Good, not Evil.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * --
 *
 * @author Luke Ward <flabbyrabbit@gmail.com>
 * @license http://opensource.org/licenses/mit-license.php MIT License
 * @link https://github.com/flabbyrabbit/minifier-php
 */

require_once("vendor/class.minijs.php");
require_once("vendor/class.scss.php");

class loader {
    /*
     * Base directories can be assigned for both javascript and css
     * when all files reside within a common directory. A min folder
     * will be generated at these locations to store generated files
     */
    var $js_base = '/files/js/';
    var $css_base = '/files/css/';

    /*
     * Default file arrays for both JS and CSS contain common files
     * across the application. These will be generated seperately to any
     * files that are specific to portions of the application
     */
    var $default_js = Array( 'utils.js', 'happy.js', 'jquery.tmpl.js', 'iso8601.js', 'jquery.mCustomScrollbar.js',
                             'jquery.sticky.js', 'jquery.placeholder.min.js', 'jquery.autosize.js', 'jquery.selectmenu.js',
                             'favcounter.js',  'jquery.fancybox.js', 'main.js');
    var $default_css = Array('normalize.css', 'icomoon.css', 'responsive-gs-24col.scss', 'h5dp.css', 'hint.css',
                             'fancybox.css', 'main.scss', 'navigation.scss', 'interaction.scss', 'sidebar.scss',
                             'comments.scss');

    function __construct($app, $custom_css=Array(), $custom_js=Array(), $theme = 'dark') {
        $this->app = $app;
        $this->php_base = $app->config('path') . "/public_html";

        $this->theme = $theme;

        $this->custom_css = $custom_css;
        $this->custom_js = $custom_js;
        //$app->log->add("users", "inside construct of class.loader.php");
    }

    /*
     * Generates and stores minified versions of selected javascript and css files
     * Prints link and script tags for generated files
     */
    public function load($type) {
        //$log = new log($this);
        //$log->add("users", "inside load type: $type");
        if ($type == "css") {
            // Create scss compiler
            $this->scss = new scssc();

            // Load scss variables
            $this->scss_variables = file_get_contents($this->php_base . $this->css_base . "_{$this->theme}_variables.scss");
            //$log->add("users", "load() php_base: $this->php_base");
            //$log->add("users", "load() css_base: $this->css_base");
            //$log->add("users", "load() theme: $this->theme");
            //$log->add("users", "load() scss_variables: $this->scss_variables");

            //Build default CSS file
            $path = "{$this->css_base}min/{$this->theme}/main.css";
            if ($this->generate($path, $this->default_css, 'css')) {
                $buster = filemtime($this->php_base.$path);
                //$log->add("users", "load() buster: $buster");
                $css_includes = "<link rel='stylesheet' href='{$path}?{$buster}' type='text/css'/>\n";		
            }
            
            //Build custom CSS file, if required
            if (isset($this->custom_css) && is_array($this->custom_css) && count($this->custom_css)) {
                $this->custom_css = array_unique($this->custom_css);
                //generate filename to reflect contents
                $id = substr(md5(implode($this->custom_css)),0,10);
                $path = "{$this->css_base}min/{$this->theme}/extra_{$id}.css";
				//echo "path: $path <br/>";

                if ($this->generate($path, $this->custom_css, 'css')) {
                    $buster = filemtime($this->php_base.$path);
                    $css_includes .= "        <link rel='stylesheet' href='{$path}?{$buster}' type='text/css'/>\n";
                }
            }

            return $css_includes;
        } else if ($type == "js") {
            //Build default JS file
            $path = "{$this->js_base}min/main.js";
            if ($this->generate($path, $this->default_js, 'js')) {
                $buster = filemtime($this->php_base.$path);
                $js_includes = "<script type='text/javascript' src='{$path}?{$buster}'></script>\n";
            }

            //Build custom JS, if required
            if (isset($this->custom_js) && is_array($this->custom_js) && count($this->custom_js)) {
                $this->custom_js = array_unique($this->custom_js);
                //generate filename to reflect contents
                $id = substr(md5(implode($this->custom_js)),0,10);
                $path = "{$this->js_base}min/extra_{$id}.js";
                //$log->add("users", "load() path: $path");
                
                if ($this->generate($path, $this->custom_js, 'js')) {
                    $buster = filemtime($this->php_base.$path);
                    $js_includes .= "        <script type='text/javascript' src='{$path}?{$buster}'></script>\n";
                }
            }

            return $js_includes;
        }
    }

    public function add_file($filename, $type) {
        if ($type == 'js') {
            if (!is_array($this->custom_js) || !count($this->custom_js)) {
                $this->custom_js = array();
            }

            $this->custom_js = array_merge($this->custom_js, (array)$filename);
        } else if ($type == 'css') {
            if (!is_array($this->custom_css) || !count($this->custom_css)) {
                $this->custom_css = array();
            }

            $this->custom_css = array_merge($this->custom_css, (array)$filename);
        }
    }
    
    private function generate($filename, $file_array, $type) {
	//echo "1 filename: $filename, file_array: $file_array, type: $type <br/>";
        //$log = new log($this);
        //$log->add("users", "generate() filename: $filename, file_array: $file_array, type: $type");
        $cache_file = preg_replace("/[^A-Za-z0-9_-]/", '', basename($filename));
        // check how long it has been since the last check
        if ($this->app->cache->get('loader_' . $this->theme . '_'.$cache_file, 30) && !isset($_GET['generate']))        {
            //$log->add("users", "generate() cache_file: ".'loader_' . $this->theme . '_'.$cache_file);
            return true;
        }

        //create cache file so no one else gets this far
        $this->app->cache->set('loader_' . $this->theme . '_'.$cache_file, 'checked');

        if ($type == 'js') {
            $base = $this->js_base;
        } else if ($type == 'css') {
            $base = $this->css_base;
			//echo "2 base: $base <br/>";
        } else {
            return false;
        }
        $php_base = $this->php_base;
        //echo "3 php_base: $php_base <br/>";
        //$log->add("users", "generate() php_base: $php_base");

        /*
         * check if generated file already exists
         * if so store last modified time for comparison
         */
        $generate = false;
        if (file_exists($php_base.$filename)) {
            $modified = filemtime($php_base.$filename);

            foreach ($file_array as $file) {
                $filepath = $base.$file;
		//echo "3.5 php_base: $php_base , filepath: $filepath <br/>";
                //$log->add("users", "generate() filepath: $filepath");
                
                
                //echo "3.5.3 check new filemtime: ".filemtime($php_base.$filepath)." <br/>";
                //echo "3.5.3 check old filemtime: ".$modified." <br/>";
                
                if ((file_exists($php_base.$filepath)) && (filemtime($php_base.$filepath) > $modified)) {
                    $generate = true;
					//echo "3.6 php_base: $php_base , filepath: $filepath <br/>";
                    break;
                }
            }
        } else {
            $generate = true;
        }
		
	//echo "4 generate: $generate <br/>";

        if ($generate) {
	    //echo "4.1 generate: $generate <br/>";
            $contents = '';
            // load and concatenate file contents
            foreach ($file_array as $file) {
                $filepath = $base.$file;
                //echo "4.1.2 filepath: $filepath <br/>";
                if (file_exists($php_base.$filepath)) {
                    $tmp_contents = file_get_contents($php_base.$filepath) . "\n";

                    // do we need to compile with scss compiler?
                    if (substr($filepath, -4) === 'scss') {
                        $tmp_contents = $this->scss_variables . $tmp_contents;
                        $tmp_contents = $this->scss->compile($tmp_contents);
                    }

                    $contents .= $tmp_contents;
                }
            }

            // select minification rountine
            if ($type == 'js') {
                $contents = $this->minify_js($contents);
            } else if ($type == 'css') {
                $contents = $this->minify_css($contents);
            }

            // store file
			//echo "php_base: $php_base <br/>";
            file_put_contents($php_base.$filename, $contents);
        }

        return true;
    }

    private function minify_js($contents) {
        $jsmin = new JSMin($contents);
        $contents = $jsmin->min();
        return $contents;
    }
  
    private function minify_css($contents) {
        $contents = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $contents);
        $contents = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $contents);
        return $contents;
    }
}

?>
