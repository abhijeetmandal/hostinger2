<?

$conf = [
	//Change to your bot token, check the readme to know how to create and get your bot token.
	'bot_token' => 'DDDDDDDDD:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
	//Set to TRUE if you want the bot only to awnser the trusted ChatIDs
	'only_trusted' => TRUE,
	//Populate the array with the trusted Chat IDs
	'trusted' => [ 
		'<chat_id>' 
		],
	];

